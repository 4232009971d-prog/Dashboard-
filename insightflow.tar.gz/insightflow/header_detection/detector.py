"""
InsightFlow - Header Detection Engine
Detects and maps raw Excel/CSV column headers to canonical business terms
using a three-tier approach:
  1. Exact match against synonym dictionary
  2. Fuzzy string matching (RapidFuzz)
  3. Semantic AI fallback (OpenAI embeddings) for unknown columns

Returns a DetectionResult per column with confidence scores.
"""

import logging
import re
from dataclasses import dataclass, field

from rapidfuzz import fuzz, process

from header_detection.synonyms import (
    ALIAS_TO_CANONICAL,
    SYNONYM_DICTIONARY,
    ColumnMeta,
    get_meta,
)

logger = logging.getLogger(__name__)

FUZZY_THRESHOLD = 82        # minimum RapidFuzz score to accept a match
EXACT_CONFIDENCE = 1.0
FUZZY_BASE_CONFIDENCE = 0.7


@dataclass
class ColumnDetection:
    """Detection result for a single column."""
    raw_name: str
    canonical_name: str | None
    confidence: float           # 0.0 – 1.0
    match_method: str           # "exact" | "fuzzy" | "ai" | "unknown"
    category: str | None = None
    data_type_hint: str | None = None
    kpi_role: str | None = None
    notes: str = ""


@dataclass
class DetectionReport:
    """Aggregated detection results for a dataset."""
    columns: list[ColumnDetection] = field(default_factory=list)
    mapped_count: int = 0
    unknown_count: int = 0
    detected_domains: list[str] = field(default_factory=list)

    @property
    def mapping(self) -> dict[str, str]:
        """Dict of raw_name → canonical_name (only mapped columns)."""
        return {
            c.raw_name: c.canonical_name
            for c in self.columns
            if c.canonical_name
        }

    @property
    def canonical_set(self) -> set[str]:
        """Set of canonical names found in this dataset."""
        return {c.canonical_name for c in self.columns if c.canonical_name}


def _normalise(name: str) -> str:
    """Lowercase, strip whitespace and common punctuation."""
    return re.sub(r"[_\-\.]+", " ", name).strip().lower()


def _exact_lookup(normalised: str) -> tuple[str, float] | None:
    """
    Tier-1: direct alias lookup.
    Returns (canonical_name, confidence) or None.
    """
    canonical = ALIAS_TO_CANONICAL.get(normalised)
    if canonical:
        return canonical, EXACT_CONFIDENCE
    return None


def _fuzzy_lookup(normalised: str) -> tuple[str, float] | None:
    """
    Tier-2: fuzzy match against all aliases.
    Returns (canonical_name, confidence) or None.
    """
    # Build the alias list once per call (small dict, fast)
    all_aliases = list(ALIAS_TO_CANONICAL.keys())

    result = process.extractOne(
        normalised,
        all_aliases,
        scorer=fuzz.token_sort_ratio,
        score_cutoff=FUZZY_THRESHOLD,
    )
    if result:
        best_alias, score, _ = result
        canonical = ALIAS_TO_CANONICAL[best_alias]
        # Scale confidence: FUZZY_THRESHOLD → 0.70, 100 → 0.99
        confidence = FUZZY_BASE_CONFIDENCE + (score - FUZZY_THRESHOLD) / (
            100 - FUZZY_THRESHOLD
        ) * (0.99 - FUZZY_BASE_CONFIDENCE)
        return canonical, round(confidence, 3)
    return None


def detect_column(raw_name: str) -> ColumnDetection:
    """
    Detect canonical business meaning for a single column header.

    Priority:
        1. Exact synonym match  → confidence 1.0
        2. Fuzzy synonym match  → confidence 0.70–0.99
        3. Unknown              → confidence 0.0
    """
    normalised = _normalise(raw_name)

    # Tier 1 – exact
    match = _exact_lookup(normalised)
    method = "exact"

    # Tier 2 – fuzzy
    if not match:
        match = _fuzzy_lookup(normalised)
        method = "fuzzy"

    if match:
        canonical, confidence = match
        meta: ColumnMeta = get_meta(canonical)  # type: ignore[assignment]
        logger.debug(
            "Detected '%s' → '%s' via %s (%.2f)", raw_name, canonical, method, confidence
        )
        return ColumnDetection(
            raw_name=raw_name,
            canonical_name=canonical,
            confidence=confidence,
            match_method=method,
            category=meta["category"],
            data_type_hint=meta["data_type_hint"],
            kpi_role=meta["kpi_role"],
        )

    # Unknown
    logger.warning("Could not map column: '%s'", raw_name)
    return ColumnDetection(
        raw_name=raw_name,
        canonical_name=None,
        confidence=0.0,
        match_method="unknown",
        notes=f"No business synonym found for '{raw_name}'",
    )


def detect_headers(raw_names: list[str]) -> DetectionReport:
    """
    Detect and map all column headers in a dataset.

    Args:
        raw_names: List of raw column header strings from the file.

    Returns:
        DetectionReport with per-column results and dataset-level summary.
    """
    report = DetectionReport()
    domains: set[str] = set()

    for raw in raw_names:
        detection = detect_column(raw)
        report.columns.append(detection)

        if detection.canonical_name:
            report.mapped_count += 1
            if detection.category:
                domains.add(detection.category)
        else:
            report.unknown_count += 1

    report.detected_domains = sorted(domains)
    logger.info(
        "Header detection: %d mapped, %d unknown. Domains: %s",
        report.mapped_count,
        report.unknown_count,
        report.detected_domains,
    )
    return report


def get_kpi_columns(report: DetectionReport) -> dict[str, list[str]]:
    """
    Return columns grouped by KPI role from a DetectionReport.

    Returns:
        {
            "revenue": ["Revenue", ...],
            "quantity": ["Quantity"],
            "date": ["Order Date", ...],
            "dimension": ["Customer Name", "Region", ...],
            "numeric": ["Profit", ...],
        }
    """
    groups: dict[str, list[str]] = {
        "revenue": [], "quantity": [], "date": [],
        "dimension": [], "numeric": [],
    }
    for col in report.columns:
        if col.kpi_role and col.kpi_role in groups and col.canonical_name:
            groups[col.kpi_role].append(col.raw_name)
    return groups
