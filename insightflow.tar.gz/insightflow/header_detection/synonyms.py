"""
InsightFlow - Business Column Synonym Dictionary
Maps hundreds of real-world column name variants to canonical business terms.

Structure:
    CANONICAL_NAME: {
        "aliases": [...],       # exact / partial match strings
        "category": str,        # business domain
        "data_type_hint": str,  # expected dtype
        "kpi_role": str | None  # role in KPI calculation
    }
"""

from typing import TypedDict


class ColumnMeta(TypedDict):
    aliases: list[str]
    category: str
    data_type_hint: str          # "numeric" | "text" | "date" | "boolean" | "id"
    kpi_role: str | None         # "revenue" | "quantity" | "date" | "dimension" | None


SYNONYM_DICTIONARY: dict[str, ColumnMeta] = {

    # ── Identifiers ───────────────────────────────────────────────────────────
    "Customer ID": {
        "aliases": [
            "customer_id", "cust_id", "cust id", "customerid", "client_id",
            "client id", "clientid", "cid", "customer no", "customer number",
            "client no", "buyer id", "account id", "account_id", "acct id",
            "acct_id", "consumer id", "shopper id", "member id",
        ],
        "category": "customer",
        "data_type_hint": "id",
        "kpi_role": "dimension",
    },
    "Customer Name": {
        "aliases": [
            "customer_name", "cust_name", "customer name", "client_name",
            "client name", "clientname", "buyer name", "account name",
            "consumer name", "shopper name", "member name", "full name",
            "contact name", "company name", "organization",
        ],
        "category": "customer",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "Order ID": {
        "aliases": [
            "order_id", "orderid", "order id", "order no", "order number",
            "orderno", "order #", "transaction id", "txn id", "trans id",
            "sale id", "saleid", "reference id", "ref id", "ref no",
        ],
        "category": "order",
        "data_type_hint": "id",
        "kpi_role": "dimension",
    },
    "Invoice Number": {
        "aliases": [
            "invoice_number", "invoice number", "invoice no", "invoice#",
            "inv no", "inv number", "inv_no", "bill no", "bill number",
            "invoice id", "invoiceid",
        ],
        "category": "finance",
        "data_type_hint": "id",
        "kpi_role": "dimension",
    },
    "Product ID": {
        "aliases": [
            "product_id", "productid", "product id", "prod id", "prod_id",
            "item id", "item_id", "sku", "stock keeping unit", "part id",
            "part no", "part number", "article id", "article no",
        ],
        "category": "product",
        "data_type_hint": "id",
        "kpi_role": "dimension",
    },

    # ── Product / Item ─────────────────────────────────────────────────────────
    "Product Name": {
        "aliases": [
            "product_name", "product name", "productname", "prod name",
            "item name", "item_name", "article name", "description",
            "product description", "item description", "product title",
            "goods", "merchandise",
        ],
        "category": "product",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "Category": {
        "aliases": [
            "category", "cat", "product category", "item category",
            "product type", "item type", "type", "group", "product group",
            "segment", "class", "classification", "department",
            "product line", "line",
        ],
        "category": "product",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "SKU": {
        "aliases": [
            "sku", "stock keeping unit", "sku code", "sku number",
            "barcode", "upc", "ean", "part number", "model number",
        ],
        "category": "product",
        "data_type_hint": "id",
        "kpi_role": "dimension",
    },

    # ── Financial ─────────────────────────────────────────────────────────────
    "Revenue": {
        "aliases": [
            "revenue", "sales", "sales amount", "sales value", "net sales",
            "gross sales", "amount", "net amount", "invoice amount",
            "total amount", "total sales", "sale amount", "turnover",
            "income", "proceeds", "receipts", "billing amount",
            "billed amount", "charged amount", "value",
            "total value", "line total", "extended price",
        ],
        "category": "finance",
        "data_type_hint": "numeric",
        "kpi_role": "revenue",
    },
    "Profit": {
        "aliases": [
            "profit", "net profit", "gross profit", "earnings",
            "net income", "net earnings", "margin amount", "gain",
            "profit amount", "operating profit", "ebit",
        ],
        "category": "finance",
        "data_type_hint": "numeric",
        "kpi_role": "numeric",
    },
    "Cost": {
        "aliases": [
            "cost", "cost price", "unit cost", "cogs",
            "cost of goods sold", "purchase price", "buy price",
            "landed cost", "total cost", "expenses", "expenditure",
        ],
        "category": "finance",
        "data_type_hint": "numeric",
        "kpi_role": "numeric",
    },
    "Discount": {
        "aliases": [
            "discount", "discount amount", "discount value", "rebate",
            "markdown", "allowance", "price reduction", "deduction",
            "discount %", "discount percent", "discount rate",
        ],
        "category": "finance",
        "data_type_hint": "numeric",
        "kpi_role": "numeric",
    },
    "Tax": {
        "aliases": [
            "tax", "tax amount", "vat", "gst", "hst", "sales tax",
            "tax value", "tax rate", "duty",
        ],
        "category": "finance",
        "data_type_hint": "numeric",
        "kpi_role": "numeric",
    },
    "Unit Price": {
        "aliases": [
            "unit price", "price", "selling price", "sale price", "list price",
            "retail price", "mrp", "rate", "unit rate", "price per unit",
            "each", "per unit",
        ],
        "category": "finance",
        "data_type_hint": "numeric",
        "kpi_role": "numeric",
    },

    # ── Quantity ───────────────────────────────────────────────────────────────
    "Quantity": {
        "aliases": [
            "quantity", "qty", "units", "unit quantity", "no of units",
            "number of units", "pieces", "pcs", "count", "volume",
            "amount ordered", "ordered qty", "shipped qty",
            "quantity ordered", "quantity sold",
        ],
        "category": "order",
        "data_type_hint": "numeric",
        "kpi_role": "quantity",
    },

    # ── Dates ─────────────────────────────────────────────────────────────────
    "Order Date": {
        "aliases": [
            "order date", "order_date", "orderdate", "sale date", "sale_date",
            "transaction date", "txn date", "purchase date", "date ordered",
            "placed date", "booking date",
        ],
        "category": "time",
        "data_type_hint": "date",
        "kpi_role": "date",
    },
    "Invoice Date": {
        "aliases": [
            "invoice date", "invoice_date", "invoicedate", "bill date",
            "billing date", "invoice raised date",
        ],
        "category": "time",
        "data_type_hint": "date",
        "kpi_role": "date",
    },
    "Ship Date": {
        "aliases": [
            "ship date", "ship_date", "shipdate", "shipment date",
            "shipped date", "dispatch date", "despatch date",
            "delivery date", "delivered date", "estimated delivery",
        ],
        "category": "time",
        "data_type_hint": "date",
        "kpi_role": "date",
    },
    "Date": {
        "aliases": [
            "date", "dt", "period", "reporting date", "as of date",
            "effective date", "posting date", "value date",
        ],
        "category": "time",
        "data_type_hint": "date",
        "kpi_role": "date",
    },

    # ── Geography ─────────────────────────────────────────────────────────────
    "Country": {
        "aliases": [
            "country", "country name", "nation", "country code",
            "ship to country", "bill to country",
        ],
        "category": "geography",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "Region": {
        "aliases": [
            "region", "sales region", "territory", "zone",
            "area", "district", "market", "geography",
        ],
        "category": "geography",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "State": {
        "aliases": [
            "state", "state name", "province", "prefecture",
            "state code", "county",
        ],
        "category": "geography",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "City": {
        "aliases": [
            "city", "city name", "town", "municipality", "locality",
        ],
        "category": "geography",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "Postal Code": {
        "aliases": [
            "postal code", "zip code", "zip", "postcode", "pin code",
            "pin", "area code",
        ],
        "category": "geography",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },

    # ── Logistics ─────────────────────────────────────────────────────────────
    "Supplier": {
        "aliases": [
            "supplier", "supplier name", "vendor", "vendor name",
            "manufacturer", "producer", "distributor", "partner",
        ],
        "category": "supply_chain",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "Warehouse": {
        "aliases": [
            "warehouse", "warehouse name", "warehouse code", "location",
            "storage location", "fulfillment center", "dc",
            "distribution center", "depot",
        ],
        "category": "supply_chain",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },

    # ── Inventory ─────────────────────────────────────────────────────────────
    "Stock Quantity": {
        "aliases": [
            "stock", "stock quantity", "stock level", "inventory",
            "inventory level", "on hand", "qty on hand", "available qty",
            "units on hand", "units available", "balance",
        ],
        "category": "inventory",
        "data_type_hint": "numeric",
        "kpi_role": "quantity",
    },
    "Reorder Level": {
        "aliases": [
            "reorder level", "reorder point", "min stock", "minimum stock",
            "safety stock", "reorder qty", "min qty",
        ],
        "category": "inventory",
        "data_type_hint": "numeric",
        "kpi_role": "numeric",
    },

    # ── Status ────────────────────────────────────────────────────────────────
    "Payment Status": {
        "aliases": [
            "payment status", "pay status", "paid status", "payment",
            "settled", "payment flag", "invoice status",
        ],
        "category": "finance",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
    "Order Status": {
        "aliases": [
            "order status", "status", "fulfillment status",
            "shipping status", "delivery status", "line status",
        ],
        "category": "order",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },

    # ── People / HR ───────────────────────────────────────────────────────────
    "Sales Rep": {
        "aliases": [
            "sales rep", "sales person", "salesperson", "rep", "agent",
            "sales agent", "account manager", "am", "sales executive",
            "sales associate", "employee name",
        ],
        "category": "hr",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },

    # ── Currency ──────────────────────────────────────────────────────────────
    "Currency": {
        "aliases": [
            "currency", "currency code", "ccy", "fx", "forex",
            "denomination",
        ],
        "category": "finance",
        "data_type_hint": "text",
        "kpi_role": "dimension",
    },
}


# ── Reverse index: alias → canonical name ──────────────────────────────────────
ALIAS_TO_CANONICAL: dict[str, str] = {}
for canonical, meta in SYNONYM_DICTIONARY.items():
    for alias in meta["aliases"]:
        ALIAS_TO_CANONICAL[alias.lower().strip()] = canonical


def get_canonical(raw_name: str) -> str | None:
    """Return canonical column name for a raw header, or None if unknown."""
    return ALIAS_TO_CANONICAL.get(raw_name.lower().strip())


def get_meta(canonical_name: str) -> ColumnMeta | None:
    """Return metadata for a canonical column name."""
    return SYNONYM_DICTIONARY.get(canonical_name)
