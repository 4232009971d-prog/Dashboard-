"""
InsightFlow - KPI Engine
Automatically computes business KPIs from a cleaned DataFrame
based on detected column roles.
"""

import logging
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from header_detection.detector import DetectionReport, get_kpi_columns

logger = logging.getLogger(__name__)


@dataclass
class KPI:
    name: str
    value: Any
    formatted: str
    delta: float | None = None        # % change vs prior period
    delta_label: str = ""
    icon: str = "📊"
    description: str = ""


class KPIEngine:
    """
    Computes a standard KPI card set from any detected dataset.
    Returns a list of KPI objects ready for display.
    """

    def compute(
        self,
        df: pd.DataFrame,
        detection: DetectionReport,
    ) -> list[KPI]:
        kpis: list[KPI] = []
        groups = get_kpi_columns(detection)

        revenue_cols = groups["revenue"]
        qty_cols = groups["quantity"]
        date_cols = groups["date"]
        dim_cols = groups["dimension"]

        # ── Total Revenue ──────────────────────────────────────────────────────
        if revenue_cols:
            col = revenue_cols[0]
            total = self._safe_sum(df, col)
            kpis.append(KPI(
                name="Total Revenue",
                value=total,
                formatted=self._fmt_currency(total),
                icon="💰",
                description=f"Sum of {col}",
            ))

            # Average order value
            if not df.empty:
                aov = total / len(df)
                kpis.append(KPI(
                    name="Avg Order Value",
                    value=aov,
                    formatted=self._fmt_currency(aov),
                    icon="🛒",
                ))

        # ── Total Quantity ─────────────────────────────────────────────────────
        if qty_cols:
            col = qty_cols[0]
            total_qty = self._safe_sum(df, col)
            kpis.append(KPI(
                name="Total Units Sold",
                value=total_qty,
                formatted=f"{int(total_qty):,}",
                icon="📦",
            ))

        # ── Order / Row Count ──────────────────────────────────────────────────
        kpis.append(KPI(
            name="Total Orders",
            value=len(df),
            formatted=f"{len(df):,}",
            icon="📋",
        ))

        # ── Customer Count ─────────────────────────────────────────────────────
        customer_col = self._find_col(df, detection, "customer")
        if customer_col:
            n_customers = df[customer_col].nunique()
            kpis.append(KPI(
                name="Unique Customers",
                value=n_customers,
                formatted=f"{n_customers:,}",
                icon="👥",
            ))

        # ── Product Count ──────────────────────────────────────────────────────
        product_col = self._find_col(df, detection, "product")
        if product_col:
            n_products = df[product_col].nunique()
            kpis.append(KPI(
                name="Unique Products",
                value=n_products,
                formatted=f"{n_products:,}",
                icon="🏷️",
            ))

        # ── Profit ─────────────────────────────────────────────────────────────
        profit_cols = [
            c for c in detection.columns
            if c.canonical_name == "Profit" and c.canonical_name
        ]
        if profit_cols:
            raw = profit_cols[0].raw_name
            total_profit = self._safe_sum(df, raw)
            kpis.append(KPI(
                name="Total Profit",
                value=total_profit,
                formatted=self._fmt_currency(total_profit),
                icon="📈",
            ))

            if revenue_cols:
                rev = self._safe_sum(df, revenue_cols[0])
                margin = (total_profit / rev * 100) if rev else 0
                kpis.append(KPI(
                    name="Profit Margin",
                    value=margin,
                    formatted=f"{margin:.1f}%",
                    icon="💹",
                ))

        # ── Date Range ────────────────────────────────────────────────────────
        if date_cols:
            date_col = date_cols[0]
            if pd.api.types.is_datetime64_any_dtype(df[date_col]):
                date_range = f"{df[date_col].min().date()} – {df[date_col].max().date()}"
                kpis.append(KPI(
                    name="Date Range",
                    value=date_range,
                    formatted=date_range,
                    icon="📅",
                ))

        logger.info("Computed %d KPIs.", len(kpis))
        return kpis

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _safe_sum(self, df: pd.DataFrame, col: str) -> float:
        try:
            return float(pd.to_numeric(df[col], errors="coerce").sum())
        except Exception:
            return 0.0

    def _fmt_currency(self, value: float) -> str:
        if abs(value) >= 1_000_000:
            return f"${value / 1_000_000:.2f}M"
        if abs(value) >= 1_000:
            return f"${value / 1_000:.1f}K"
        return f"${value:,.2f}"

    def _find_col(
        self, df: pd.DataFrame, detection: DetectionReport, category: str
    ) -> str | None:
        """Find first raw column name matching a category that exists in df."""
        for c in detection.columns:
            if c.category == category and c.raw_name in df.columns:
                return c.raw_name
        return None
