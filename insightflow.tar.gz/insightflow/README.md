# ⚡ InsightFlow

**AI-powered Instant Dashboard Generator**

Upload any Excel or CSV file and get interactive dashboards, KPIs, data quality reports, and AI business insights — automatically, in seconds.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🧠 **Auto Column Detection** | Maps 200+ business column synonyms to canonical names using exact + fuzzy matching |
| 🧹 **Data Cleaning** | Removes duplicates, fixes dates, trims whitespace, detects missing values |
| 📊 **Auto Dashboard** | Generates relevant Plotly charts based on what data exists |
| 💰 **KPI Cards** | Revenue, Orders, Customers, Products, Profit, Margin — computed automatically |
| 💡 **AI Insights** | Natural language findings about trends, top products, customer concentration |
| 💬 **Chat with Data** | Ask questions in plain English about your dataset |
| 🔬 **Quality Report** | Column-level missing value analysis, data health score |
| 🔐 **Authentication** | JWT-based login / register via FastAPI backend |
| 🐳 **Docker Ready** | Single `docker-compose up` to run everything |

---

## 🚀 Quick Start

### Option 1 — Streamlit Only (Recommended for MVP)

```bash
git clone https://github.com/yourname/insightflow.git
cd insightflow

python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt

streamlit run frontend/app.py
```

Open http://localhost:8501 and upload any `.xlsx` or `.csv` file.

### Option 2 — Full Stack (FastAPI + Streamlit)

```bash
cp .env.example .env
# Edit .env with your settings

# Terminal 1 — Backend
uvicorn backend.main:app --reload --port 8000

# Terminal 2 — Frontend
streamlit run frontend/app.py
```

### Option 3 — Docker

```bash
docker-compose up --build
```

- Frontend: http://localhost:8501
- API docs: http://localhost:8000/api/docs

---

## 📁 Project Structure

```
insightflow/
├── frontend/
│   └── app.py                    # Streamlit UI (all pages)
│
├── backend/
│   ├── main.py                   # FastAPI entry point
│   ├── api/
│   │   ├── auth_router.py        # /api/auth (register, login, refresh)
│   │   ├── upload_router.py      # /api/uploads (file upload + pipeline)
│   │   └── dashboard_router.py   # /api/dashboard (chat with data)
│   ├── authentication/
│   │   └── auth_service.py       # JWT + bcrypt
│   └── database/
│       ├── models.py             # SQLAlchemy ORM models
│       └── session.py            # Engine + session factory
│
├── header_detection/
│   ├── synonyms.py               # 200+ business column synonyms dict
│   └── detector.py               # 3-tier: exact → fuzzy → AI
│
├── services/
│   └── ingestion.py              # File reading + data cleaning
│
├── dashboard_engine/
│   └── kpi_engine.py             # Automatic KPI computation
│
├── chart_engine/
│   └── chart_engine.py           # Plotly chart auto-generation
│
├── ai_engine/
│   └── insights_engine.py        # Rule-based + LLM business insights
│
├── config/
│   └── settings.py               # Pydantic settings (env-driven)
│
├── tests/
│   └── unit/
│       ├── test_header_detection.py
│       └── test_ingestion.py
│
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
└── .env.example
```

---

## 🗂️ Supported Column Types

InsightFlow automatically recognises over **200 business column name variants** across these domains:

- **Finance**: Revenue, Sales, Amount, Net Amount, Invoice Amount → `Revenue`
- **Customer**: Cust ID, Client ID, CID, Customer No → `Customer ID`
- **Product**: Item Name, Article, Description, Product Title → `Product Name`
- **Time**: Order Date, Sale Date, Transaction Date → `Order Date`
- **Geography**: Country, Nation, Region, Territory, Zone → mapped correctly
- **Inventory**: Stock, On Hand, Available Qty → `Stock Quantity`
- ...and many more

---

## 🤖 Auto Dashboard Logic

| Detected Columns | Charts Generated |
|-----------------|-----------------|
| Date + Revenue | Monthly Revenue Trend, MoM Growth |
| Product + Revenue | Top Products by Revenue |
| Product + Quantity | Top Products by Units Sold |
| Customer + Revenue | Top Customers |
| Region + Revenue | Revenue by Region (donut) |
| Country + Revenue | World Choropleth Map |
| Revenue + Profit + Date | Revenue vs Profit combo chart |

---

## 🔌 API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/register` | Create account |
| POST | `/api/auth/login` | Get JWT tokens |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/uploads/` | Upload file + run pipeline |
| GET  | `/api/uploads/` | List user's uploads |
| GET  | `/api/uploads/{id}` | Get analysis results |
| POST | `/api/dashboard/{id}/chat` | Chat with data |
| GET  | `/api/health` | Health check |

Full interactive docs at http://localhost:8000/api/docs

---

## 🧪 Running Tests

```bash
pytest tests/ -v
```

---

## ☁️ Deployment

### Streamlit Cloud

1. Push to GitHub
2. Connect repo at share.streamlit.io
3. Set `PYTHONPATH=.` in Streamlit secrets

### Render / Azure

Use the provided `Dockerfile`. Set `DATABASE_URL` to a managed PostgreSQL instance.

---

## 🛠️ Configuration

All settings are driven by environment variables (see `.env.example`):

| Variable | Default | Description |
|----------|---------|-------------|
| `DATABASE_URL` | `sqlite:///./insightflow.db` | DB connection string |
| `SECRET_KEY` | — | JWT signing key (required in prod) |
| `OPENAI_API_KEY` | — | Enables richer AI insights |
| `MAX_UPLOAD_SIZE_MB` | `50` | Max file size |

---

## 📐 Architecture Principles

- **SOLID** — each module has a single responsibility
- **Clean architecture** — ingest → detect → clean → KPI → chart → insight
- **Type hints** throughout
- **Structured logging** at every processing step
- **Exception handling** — graceful errors, never silent failures
- **DB-agnostic** — swap SQLite → PostgreSQL with one env var

---

## 🗺️ Roadmap

- [ ] PDF / PowerPoint export
- [ ] LLM-powered chat (OpenAI function calling)
- [ ] Multi-sheet dashboard tabs
- [ ] React frontend migration
- [ ] Scheduled refresh / data connectors
- [ ] Collaborative sharing links

---

## License

MIT
