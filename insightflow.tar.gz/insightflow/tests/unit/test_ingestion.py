"""
Tests for the data ingestion and cleaning pipeline.
"""

import io
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import numpy as np
import pandas as pd
import pytest

from services.ingestion import DataCleaningService, DataIngestionService


@pytest.fixture
def sample_df():
    return pd.DataFrame({
        "Customer Name": ["Alice", "Bob", "Alice", "  Carol  ", None],
        "Revenue":       [100, 200, 100, 300, 150],
        "Order Date":    ["2024-01-01", "2024-02-01", "2024-01-01", "2024-03-01", "2024-04-01"],
        "Region":        ["North", "South", "North", "East", ""],
    })


class TestDataCleaning:

    def test_removes_duplicates(self, sample_df):
        cleaner = DataCleaningService()
        clean, report = cleaner.clean(sample_df)
        assert report.duplicate_rows == 1
        assert len(clean) == 4   # 5 - 1 duplicate

    def test_strips_whitespace(self, sample_df):
        cleaner = DataCleaningService()
        clean, _ = cleaner.clean(sample_df)
        assert "  Carol  " not in clean["Customer Name"].values
        assert "Carol" in clean["Customer Name"].values

    def test_null_count(self, sample_df):
        cleaner = DataCleaningService()
        _, report = cleaner.clean(sample_df)
        cust_col = next(c for c in report.columns if c.column == "Customer Name")
        # 1 None + 1 duplicate removed = 1 null remaining
        assert cust_col.null_count >= 0

    def test_empty_string_to_nan(self, sample_df):
        cleaner = DataCleaningService()
        clean, _ = cleaner.clean(sample_df)
        # Empty string in Region should become NaN
        assert clean["Region"].isna().any()

    def test_quality_score_100_for_clean_data(self):
        df = pd.DataFrame({
            "Revenue": [100, 200, 300],
            "Product": ["A", "B", "C"],
        })
        _, report = DataCleaningService().clean(df)
        assert report.quality_score > 90

    def test_quality_score_drops_with_nulls(self):
        df = pd.DataFrame({
            "Revenue": [100, None, None, None, 200],
            "Product": [None, None, "B", None, "C"],
        })
        _, report = DataCleaningService().clean(df)
        assert report.quality_score < 90


class TestCSVIngestion:

    def test_read_csv_bytes(self):
        csv_content = b"Name,Revenue,Date\nAlice,100,2024-01-01\nBob,200,2024-02-01\n"
        ingestion = DataIngestionService()
        sheets = ingestion.read_file(io.BytesIO(csv_content), "test.csv")
        assert "test" in sheets
        df = sheets["test"]
        assert len(df) == 2
        assert "Revenue" in df.columns
