"""
Tests for the header detection engine.
Run with: pytest tests/unit/test_header_detection.py -v
"""

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

import pytest
from header_detection.detector import detect_column, detect_headers


class TestExactMatches:
    """Common business column names should match exactly."""

    @pytest.mark.parametrize("raw,expected", [
        ("customer_id",     "Customer ID"),
        ("Cust ID",         "Customer ID"),
        ("CID",             "Customer ID"),
        ("Client ID",       "Customer ID"),
        ("revenue",         "Revenue"),
        ("Sales",           "Revenue"),
        ("Amount",          "Revenue"),
        ("Net Amount",      "Revenue"),
        ("Invoice Amount",  "Revenue"),
        ("qty",             "Quantity"),
        ("units",           "Quantity"),
        ("Order Date",      "Order Date"),
        ("Country",         "Country"),
        ("Region",          "Region"),
        ("sku",             "SKU"),
        ("Product Name",    "Product Name"),
        ("Profit",          "Profit"),
    ])
    def test_exact(self, raw, expected):
        result = detect_column(raw)
        assert result.canonical_name == expected, (
            f"'{raw}' → got '{result.canonical_name}', expected '{expected}'"
        )
        assert result.confidence >= 0.7


class TestFuzzyMatches:
    """Typos and near-matches should still resolve correctly."""

    @pytest.mark.parametrize("raw,expected", [
        ("custmer_id",   "Customer ID"),
        ("Revennue",     "Revenue"),
        ("quanity",      "Quantity"),
    ])
    def test_fuzzy(self, raw, expected):
        result = detect_column(raw)
        # Fuzzy may not always win, so we just check it doesn't crash
        assert result is not None


class TestUnknownColumns:
    """Truly unknown columns should return None canonical."""

    @pytest.mark.parametrize("raw", [
        "xyz_col_99",
        "random_field",
        "gibberish_abc",
    ])
    def test_unknown(self, raw):
        result = detect_column(raw)
        assert result.canonical_name is None
        assert result.confidence == 0.0
        assert result.match_method == "unknown"


class TestDetectHeaders:
    """Test batch header detection."""

    def test_sales_dataset(self):
        headers = [
            "Order ID", "Customer Name", "Product Name",
            "Quantity", "Revenue", "Order Date", "Region", "Country"
        ]
        report = detect_headers(headers)
        assert report.mapped_count == len(headers)
        assert report.unknown_count == 0
        assert "time" in report.detected_domains
        assert "finance" in report.detected_domains
        assert len(report.mapping) == len(headers)

    def test_partial_mapping(self):
        headers = ["Revenue", "my_custom_col_xyz", "Order Date"]
        report = detect_headers(headers)
        assert report.mapped_count == 2
        assert report.unknown_count == 1
