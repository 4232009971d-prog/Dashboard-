"""
InsightFlow - Dashboard / Chat API Router
Provides the "Chat with Data" AI assistant endpoint.
"""

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.authentication.auth_service import get_user_id_from_token
from backend.database.models import ChatMessage, Upload, User
from backend.database.session import get_db

logger = logging.getLogger(__name__)
router = APIRouter()
bearer = HTTPBearer()


def _get_user(
    creds: Annotated[HTTPAuthorizationCredentials, Depends(bearer)],
    db: Session = Depends(get_db),
) -> User:
    uid = get_user_id_from_token(creds.credentials)
    if not uid:
        raise HTTPException(status_code=401, detail="Invalid token.")
    user = db.query(User).get(uid)
    if not user:
        raise HTTPException(status_code=401, detail="User not found.")
    return user


class ChatRequest(BaseModel):
    question: str


class ChatResponse(BaseModel):
    answer: str
    upload_id: str


@router.post("/{upload_id}/chat", response_model=ChatResponse)
def chat_with_data(
    upload_id: str,
    body: ChatRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(_get_user),
):
    record = db.query(Upload).get(upload_id)
    if not record or record.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Upload not found.")

    if record.status != "done":
        raise HTTPException(status_code=400, detail="Upload not yet processed.")

    # Build context from stored analysis
    kpis = record.kpi_data or []
    insights = record.insights or []
    quality = record.quality_report or {}
    detection = record.detection_report or []

    context = _build_context(record, kpis, insights, quality, detection)
    answer = _rule_based_answer(body.question, context, kpis, insights)

    # Persist chat history
    db.add(ChatMessage(upload_id=upload_id, role="user", content=body.question))
    db.add(ChatMessage(upload_id=upload_id, role="assistant", content=answer))
    db.commit()

    return ChatResponse(answer=answer, upload_id=upload_id)


def _build_context(record, kpis, insights, quality, detection) -> dict:
    return {
        "file_name": record.file_name,
        "rows": record.row_count,
        "columns": record.column_count,
        "kpis": kpis,
        "insights": insights,
        "quality_score": quality.get("quality_score"),
        "columns_detected": [
            f"{c['raw_name']} → {c['canonical_name']}" for c in detection if c.get("canonical_name")
        ],
    }


def _rule_based_answer(question: str, ctx: dict, kpis: list, insights: list) -> str:
    """
    Fast rule-based Q&A using stored analysis results.
    In production this is replaced by an LLM call with full context.
    """
    q = question.lower()

    kpi_map = {k["name"].lower(): k for k in kpis}

    if any(w in q for w in ["total revenue", "revenue", "sales"]):
        kpi = kpi_map.get("total revenue")
        if kpi:
            return f"Total revenue is **{kpi['formatted']}**."

    if any(w in q for w in ["orders", "order count", "transactions"]):
        kpi = kpi_map.get("total orders")
        if kpi:
            return f"There are **{kpi['formatted']}** total orders in this dataset."

    if any(w in q for w in ["customers", "unique customers"]):
        kpi = kpi_map.get("unique customers")
        if kpi:
            return f"The dataset contains **{kpi['formatted']}** unique customers."

    if any(w in q for w in ["products", "unique products", "items"]):
        kpi = kpi_map.get("unique products")
        if kpi:
            return f"There are **{kpi['formatted']}** unique products in this dataset."

    if any(w in q for w in ["profit", "margin"]):
        kpi = kpi_map.get("profit margin") or kpi_map.get("total profit")
        if kpi:
            return f"{kpi['name']}: **{kpi['formatted']}**."

    if any(w in q for w in ["quality", "data quality", "missing", "issues"]):
        qs = ctx.get("quality_score", "N/A")
        return f"Data quality score is **{qs}/100**. Review the Data Quality tab for column-level details."

    if any(w in q for w in ["insight", "summary", "overview"]):
        top = [i["text"] for i in insights[:3]]
        if top:
            return "Key insights:\n\n" + "\n\n".join(f"• {t}" for t in top)

    if any(w in q for w in ["columns", "fields", "headers"]):
        cols = ctx.get("columns_detected", [])
        return f"Detected **{len(cols)}** business columns:\n\n" + "\n".join(f"• {c}" for c in cols[:15])

    # Fallback
    all_kpi_text = "\n".join(f"• {k['name']}: {k['formatted']}" for k in kpis)
    return (
        f"Here's a summary of **{ctx['file_name']}** ({ctx['rows']:,} rows):\n\n"
        + all_kpi_text
        + "\n\nAsk me about revenue, customers, products, or data quality for more details."
    )
