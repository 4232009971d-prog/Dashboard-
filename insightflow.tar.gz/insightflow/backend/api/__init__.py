from backend.api import auth_router, upload_router, dashboard_router

__all__ = ["auth_router", "upload_router", "dashboard_router"]
