"""
InsightFlow - Upload API Router
Handles file uploads, runs the full analysis pipeline,
and persists results to the database.
"""

import io
import logging
from datetime import datetime
from typing import Annotated

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel
from sqlalchemy.orm import Session

from backend.authentication.auth_service import get_user_id_from_token
from backend.database.models import Upload, User
from backend.database.session import get_db
from config.settings import settings
from dashboard_engine.kpi_engine import KPIEngine
from chart_engine.chart_engine import ChartEngine
from header_detection.detector import detect_headers
from ai_engine.insights_engine import InsightsEngine
from services.ingestion import DataCleaningService, DataIngestionService

logger = logging.getLogger(__name__)
router = APIRouter()
bearer = HTTPBearer()


# ── Auth dependency ────────────────────────────────────────────────────────────

def get_current_user(
    creds: Annotated[HTTPAuthorizationCredentials, Depends(bearer)],
    db: Session = Depends(get_db),
) -> User:
    user_id = get_user_id_from_token(creds.credentials)
    if not user_id:
        raise HTTPException(status_code=401, detail="Invalid token.")
    user = db.query(User).get(user_id)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="User not found.")
    return user


# ── Response schemas ───────────────────────────────────────────────────────────

class UploadResponse(BaseModel):
    upload_id: str
    file_name: str
    status: str
    row_count: int | None
    column_count: int | None
    quality_score: float | None
    kpis: list[dict]
    insights: list[dict]
    detection: list[dict]
    quality_report: dict


class UploadListItem(BaseModel):
    upload_id: str
    file_name: str
    status: str
    row_count: int | None
    created_at: str
    quality_score: float | None


# ── Upload endpoint ────────────────────────────────────────────────────────────

@router.post("/", response_model=UploadResponse, status_code=status.HTTP_201_CREATED)
async def upload_file(
    file: Annotated[UploadFile, File(description="Excel or CSV file")],
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    # Validate extension
    suffix = "." + (file.filename or "").rsplit(".", 1)[-1].lower()
    if suffix not in settings.ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{suffix}'. Allowed: {settings.ALLOWED_EXTENSIONS}",
        )

    # Read bytes
    raw = await file.read()
    size_kb = len(raw) / 1024

    if size_kb > settings.MAX_UPLOAD_SIZE_MB * 1024:
        raise HTTPException(status_code=413, detail="File too large.")

    # Create DB record (pending)
    record = Upload(
        user_id=current_user.id,
        file_name=file.filename,
        file_size_kb=size_kb,
        status="processing",
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    try:
        # ── Pipeline ───────────────────────────────────────────────────────────

        # 1. Ingest
        ingestion = DataIngestionService()
        sheets = ingestion.read_file(io.BytesIO(raw), file.filename or "")

        if not sheets:
            raise ValueError("No usable data found in file.")

        # Use first non-empty sheet
        sheet_name, df_raw = next(iter(sheets.items()))

        # 2. Clean
        cleaner = DataCleaningService()
        df, quality = cleaner.clean(df_raw)

        # 3. Detect headers
        detection = detect_headers(df.columns.tolist())

        # 4. KPIs
        kpi_engine = KPIEngine()
        kpis = kpi_engine.compute(df, detection)

        # 5. Insights
        insights_engine = InsightsEngine()
        insights = insights_engine.generate(df, detection, kpis, quality)

        # 6. Update DB record
        record.status = "done"
        record.processed_at = datetime.utcnow()
        record.row_count = len(df)
        record.column_count = len(df.columns)
        record.sheet_names = list(sheets.keys())
        record.kpi_data = [
            {"name": k.name, "value": k.value, "formatted": k.formatted,
             "icon": k.icon, "description": k.description}
            for k in kpis
        ]
        record.quality_report = quality.to_dict()
        record.detection_report = [
            {"raw_name": c.raw_name, "canonical_name": c.canonical_name,
             "confidence": c.confidence, "match_method": c.match_method,
             "category": c.category, "kpi_role": c.kpi_role}
            for c in detection.columns
        ]
        record.insights = [
            {"text": i.text, "category": i.category,
             "importance": i.importance, "icon": i.icon}
            for i in insights
        ]
        db.commit()
        db.refresh(record)

        logger.info(
            "Upload complete: %s | %d rows | score %.1f",
            file.filename, len(df), quality.quality_score,
        )

        return UploadResponse(
            upload_id=record.id,
            file_name=record.file_name,
            status=record.status,
            row_count=record.row_count,
            column_count=record.column_count,
            quality_score=quality.quality_score,
            kpis=record.kpi_data,
            insights=record.insights,
            detection=record.detection_report,
            quality_report=record.quality_report,
        )

    except Exception as exc:
        logger.exception("Upload processing failed: %s", exc)
        record.status = "error"
        record.error_message = str(exc)
        db.commit()
        raise HTTPException(status_code=500, detail=f"Processing failed: {exc}") from exc


@router.get("/", response_model=list[UploadListItem])
def list_uploads(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    rows = (
        db.query(Upload)
        .filter(Upload.user_id == current_user.id)
        .order_by(Upload.created_at.desc())
        .limit(50)
        .all()
    )
    return [
        UploadListItem(
            upload_id=r.id,
            file_name=r.file_name,
            status=r.status,
            row_count=r.row_count,
            created_at=str(r.created_at),
            quality_score=(r.quality_report or {}).get("quality_score"),
        )
        for r in rows
    ]


@router.get("/{upload_id}", response_model=UploadResponse)
def get_upload(
    upload_id: str,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    record = db.query(Upload).get(upload_id)
    if not record or record.user_id != current_user.id:
        raise HTTPException(status_code=404, detail="Upload not found.")
    return UploadResponse(
        upload_id=record.id,
        file_name=record.file_name,
        status=record.status,
        row_count=record.row_count,
        column_count=record.column_count,
        quality_score=(record.quality_report or {}).get("quality_score"),
        kpis=record.kpi_data or [],
        insights=record.insights or [],
        detection=record.detection_report or [],
        quality_report=record.quality_report or {},
    )
