"""
InsightFlow - Database Models
SQLAlchemy ORM models for users, uploads, and analysis sessions.
Designed for SQLite (dev) and PostgreSQL (prod).
"""

import uuid
from datetime import datetime

from sqlalchemy import (
    Boolean, Column, DateTime, Float, ForeignKey,
    Integer, String, Text, JSON
)
from sqlalchemy.orm import DeclarativeBase, relationship


def _uuid() -> str:
    return str(uuid.uuid4())


class Base(DeclarativeBase):
    pass


class User(Base):
    __tablename__ = "users"

    id         = Column(String(36), primary_key=True, default=_uuid)
    email      = Column(String(255), unique=True, nullable=False, index=True)
    username   = Column(String(100), unique=True, nullable=False)
    full_name  = Column(String(255))
    hashed_pw  = Column(String(255), nullable=False)
    is_active  = Column(Boolean, default=True)
    is_admin   = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    uploads = relationship("Upload", back_populates="owner", cascade="all, delete-orphan")

    def __repr__(self) -> str:
        return f"<User {self.email}>"


class Upload(Base):
    __tablename__ = "uploads"

    id            = Column(String(36), primary_key=True, default=_uuid)
    user_id       = Column(String(36), ForeignKey("users.id"), nullable=False)
    file_name     = Column(String(500), nullable=False)
    file_size_kb  = Column(Float)
    file_path     = Column(String(1000))
    status        = Column(String(50), default="pending")  # pending|processing|done|error
    error_message = Column(Text)
    created_at    = Column(DateTime, default=datetime.utcnow)
    processed_at  = Column(DateTime)

    # Analysis results stored as JSON blobs
    kpi_data          = Column(JSON)   # list of KPI dicts
    quality_report    = Column(JSON)   # DataQualityReport.to_dict()
    detection_report  = Column(JSON)   # list of ColumnDetection dicts
    insights          = Column(JSON)   # list of Insight dicts
    row_count         = Column(Integer)
    column_count      = Column(Integer)
    sheet_names       = Column(JSON)   # list[str]

    owner = relationship("User", back_populates="uploads")

    def __repr__(self) -> str:
        return f"<Upload {self.file_name} [{self.status}]>"


class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id         = Column(String(36), primary_key=True, default=_uuid)
    upload_id  = Column(String(36), ForeignKey("uploads.id"), nullable=False)
    role       = Column(String(20), nullable=False)   # "user" | "assistant"
    content    = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"<ChatMessage {self.role} @ {self.created_at}>"
