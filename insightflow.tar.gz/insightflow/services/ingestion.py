"""
InsightFlow - Data Ingestion & Cleaning Service
Reads Excel workbooks and CSV files, auto-detects structure,
runs data quality checks, and produces a clean DataFrame
alongside a DataQualityReport.
"""

import io
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

logger = logging.getLogger(__name__)

# ── Data Quality Report ────────────────────────────────────────────────────────

@dataclass
class ColumnQuality:
    column: str
    dtype: str
    null_count: int
    null_pct: float
    duplicate_count: int
    unique_count: int
    sample_values: list[Any]
    issues: list[str] = field(default_factory=list)


@dataclass
class DataQualityReport:
    total_rows: int
    total_columns: int
    duplicate_rows: int
    blank_rows: int
    columns: list[ColumnQuality] = field(default_factory=list)
    global_issues: list[str] = field(default_factory=list)
    quality_score: float = 100.0   # 0–100

    def to_dict(self) -> dict:
        return {
            "total_rows": self.total_rows,
            "total_columns": self.total_columns,
            "duplicate_rows": self.duplicate_rows,
            "blank_rows": self.blank_rows,
            "quality_score": round(self.quality_score, 1),
            "global_issues": self.global_issues,
            "columns": [
                {
                    "column": c.column,
                    "dtype": c.dtype,
                    "null_count": c.null_count,
                    "null_pct": round(c.null_pct, 2),
                    "unique_count": c.unique_count,
                    "issues": c.issues,
                    "sample_values": [str(v) for v in c.sample_values[:5]],
                }
                for c in self.columns
            ],
        }


# ── Date format patterns to try ────────────────────────────────────────────────

DATE_FORMATS = [
    "%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y",
    "%m-%d-%Y", "%d.%m.%Y", "%Y%m%d", "%d %b %Y",
    "%d %B %Y", "%b %d %Y", "%B %d %Y",
    "%Y-%m-%d %H:%M:%S", "%d/%m/%Y %H:%M:%S",
]


def _try_parse_date(series: pd.Series) -> pd.Series | None:
    """Attempt to parse a string Series as dates. Returns parsed Series or None."""
    for fmt in DATE_FORMATS:
        try:
            parsed = pd.to_datetime(series, format=fmt, errors="raise")
            return parsed
        except (ValueError, TypeError):
            continue
    # Last resort: pandas inference
    try:
        return pd.to_datetime(series, infer_datetime_format=True, errors="raise")
    except Exception:
        return None


def _clean_column_name(name: str) -> str:
    """Trim whitespace from column name."""
    return str(name).strip()


# ── Ingestion ──────────────────────────────────────────────────────────────────

class DataIngestionService:
    """
    Reads raw files → clean DataFrames.

    Supports:
        - .xlsx / .xls  (all sheets)
        - .csv
    """

    def read_file(
        self,
        file_path: str | Path | io.BytesIO,
        file_name: str = "",
    ) -> dict[str, pd.DataFrame]:
        """
        Read file and return a dict of {sheet_name: DataFrame}.
        CSV files return {"Sheet1": df}.
        """
        suffix = Path(file_name).suffix.lower() if file_name else ""

        # Detect from BytesIO by inspecting first bytes
        if isinstance(file_path, io.BytesIO):
            header = file_path.read(8)
            file_path.seek(0)
            is_xlsx = header[:4] == b"PK\x03\x04"  # ZIP magic for xlsx
            is_csv = not is_xlsx
            if suffix:
                is_csv = suffix == ".csv"
                is_xlsx = suffix in (".xlsx", ".xls")
        else:
            p = Path(file_path)
            is_csv = p.suffix.lower() == ".csv"
            is_xlsx = p.suffix.lower() in (".xlsx", ".xls")

        if is_csv:
            return self._read_csv(file_path, file_name)
        elif is_xlsx:
            return self._read_excel(file_path)
        else:
            raise ValueError(f"Unsupported file type: {file_name or file_path}")

    def _read_excel(self, source) -> dict[str, pd.DataFrame]:
        try:
            xl = pd.ExcelFile(source)
            sheets: dict[str, pd.DataFrame] = {}
            for sheet in xl.sheet_names:
                try:
                    df = xl.parse(sheet, header=None)
                    df = self._detect_and_set_header(df)
                    if df is not None and not df.empty:
                        sheets[sheet] = df
                except Exception as e:
                    logger.warning("Skipping sheet '%s': %s", sheet, e)
            return sheets
        except Exception as e:
            raise RuntimeError(f"Failed to read Excel file: {e}") from e

    def _read_csv(self, source, file_name: str) -> dict[str, pd.DataFrame]:
        encodings = ["utf-8", "latin-1", "cp1252"]
        for enc in encodings:
            try:
                if isinstance(source, io.BytesIO):
                    source.seek(0)
                df = pd.read_csv(source, encoding=enc, low_memory=False)
                df.columns = [_clean_column_name(c) for c in df.columns]
                sheet_name = Path(file_name).stem or "Sheet1"
                return {sheet_name: df}
            except (UnicodeDecodeError, pd.errors.ParserError):
                continue
        raise RuntimeError("Could not decode CSV with supported encodings.")

    def _detect_and_set_header(self, df: pd.DataFrame) -> pd.DataFrame | None:
        """
        Find the true header row (first row with mostly string values).
        Skip leading blank/title rows common in business workbooks.
        """
        if df.empty:
            return None

        for i, row in df.iterrows():
            non_null = row.dropna()
            if len(non_null) < 2:
                continue
            string_ratio = sum(isinstance(v, str) for v in non_null) / len(non_null)
            if string_ratio >= 0.5:
                # Use this row as header
                df.columns = [_clean_column_name(str(v)) for v in row]
                df = df.iloc[int(i) + 1:].reset_index(drop=True)  # type: ignore[arg-type]
                # Drop fully empty rows/cols
                df.dropna(how="all", inplace=True)
                df.dropna(axis=1, how="all", inplace=True)
                return df

        # Fallback: use first row as header
        df.columns = [_clean_column_name(str(v)) for v in df.iloc[0]]
        return df.iloc[1:].reset_index(drop=True)


# ── Cleaning ───────────────────────────────────────────────────────────────────

class DataCleaningService:
    """
    Cleans a DataFrame and produces a DataQualityReport.
    """

    def clean(self, df: pd.DataFrame) -> tuple[pd.DataFrame, DataQualityReport]:
        """
        Full cleaning pipeline.
        Returns (cleaned_df, quality_report).
        """
        df = df.copy()

        # 1. Clean column names
        df.columns = [c.strip() for c in df.columns]

        # 2. Remove fully blank rows
        blank_rows = int(df.isnull().all(axis=1).sum())
        df.dropna(how="all", inplace=True)

        # 3. Remove duplicate rows
        dup_count = int(df.duplicated().sum())
        df.drop_duplicates(inplace=True)
        df.reset_index(drop=True, inplace=True)

        # 4. Per-column cleaning
        col_reports: list[ColumnQuality] = []
        for col in df.columns:
            df[col], cq = self._clean_column(df[col], col)
            col_reports.append(cq)

        # 5. Quality score
        issues_total = sum(len(c.issues) for c in col_reports)
        max_possible = len(col_reports) * 3  # up to 3 issues per column
        quality_score = max(0.0, 100.0 - (issues_total / max(max_possible, 1)) * 100)
        if dup_count > 0:
            quality_score -= min(10, dup_count / max(len(df), 1) * 100)
        quality_score = max(0.0, quality_score)

        global_issues = []
        if dup_count > 0:
            global_issues.append(f"{dup_count} duplicate rows removed.")
        if blank_rows > 0:
            global_issues.append(f"{blank_rows} fully blank rows removed.")

        report = DataQualityReport(
            total_rows=len(df),
            total_columns=len(df.columns),
            duplicate_rows=dup_count,
            blank_rows=blank_rows,
            columns=col_reports,
            global_issues=global_issues,
            quality_score=quality_score,
        )
        logger.info(
            "Data cleaned: %d rows, %d cols, quality score %.1f",
            len(df), len(df.columns), quality_score,
        )
        return df, report

    def _clean_column(
        self, series: pd.Series, col_name: str
    ) -> tuple[pd.Series, ColumnQuality]:
        issues: list[str] = []
        series = series.copy()

        # Strip string whitespace
        if series.dtype == object:
            series = series.map(lambda x: x.strip() if isinstance(x, str) else x)

        # Replace empty strings with NaN
        series.replace("", np.nan, inplace=True)
        series.replace(["N/A", "n/a", "NA", "None", "NULL", "null", "-"], np.nan, inplace=True)

        null_count = int(series.isnull().sum())
        null_pct = null_count / max(len(series), 1) * 100

        if null_pct > 50:
            issues.append(f"{null_pct:.1f}% missing values — column may be unreliable.")
        elif null_pct > 10:
            issues.append(f"{null_pct:.1f}% missing values.")

        # Attempt numeric coercion if mostly looks numeric
        if series.dtype == object:
            numeric_attempt = pd.to_numeric(
                series.str.replace(",", "", regex=False) if series.dtype == object else series,
                errors="coerce",
            )
            numeric_valid = numeric_attempt.notna().sum()
            if numeric_valid / max(len(series.dropna()), 1) > 0.85:
                series = numeric_attempt
            else:
                # Try date
                date_parsed = _try_parse_date(series.dropna())
                if date_parsed is not None:
                    date_pct = len(date_parsed) / max(len(series.dropna()), 1)
                    if date_pct > 0.85:
                        series = _try_parse_date(series)  # full series

        unique_count = int(series.nunique())
        sample = series.dropna().head(5).tolist()

        if series.dtype in (object,) and unique_count == 1 and len(series) > 1:
            issues.append("All values are identical — low information column.")

        cq = ColumnQuality(
            column=col_name,
            dtype=str(series.dtype),
            null_count=null_count,
            null_pct=null_pct,
            duplicate_count=int(series.duplicated().sum()),
            unique_count=unique_count,
            sample_values=sample,
            issues=issues,
        )
        return series, cq
