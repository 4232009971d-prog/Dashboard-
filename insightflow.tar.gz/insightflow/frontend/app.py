"""
InsightFlow - Streamlit Frontend
AI-powered Instant Dashboard Generator
"""

import io
import json
import time
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

# ── Page config (must be first Streamlit call) ────────────────────────────────

st.set_page_config(
    page_title="InsightFlow",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Inline pipeline (no backend server needed for Streamlit Cloud) ────────────

import sys
sys.path.insert(0, str(Path(__file__).parent))

from services.ingestion import DataCleaningService, DataIngestionService
from header_detection.detector import detect_headers
from dashboard_engine.kpi_engine import KPIEngine
from chart_engine.chart_engine import ChartEngine
from ai_engine.insights_engine import InsightsEngine

# ── Custom CSS ─────────────────────────────────────────────────────────────────

st.markdown("""
<style>
/* ── Root palette ─────────────────────────────────────────────────────── */
:root {
  --bg-base:    #0F1117;
  --bg-surface: #1A1D2E;
  --bg-card:    #1E2235;
  --border:     #2D3150;
  --accent:     #6366F1;
  --accent-2:   #8B5CF6;
  --success:    #10B981;
  --warn:       #F59E0B;
  --danger:     #EF4444;
  --text-1:     #F1F5F9;
  --text-2:     #94A3B8;
  --text-3:     #64748B;
}

/* ── Hide Streamlit chrome ────────────────────────────────────────────── */
#MainMenu, footer, header { visibility: hidden; }
.stDeployButton { display: none; }

/* ── Global background ────────────────────────────────────────────────── */
.stApp { background: var(--bg-base); }
section[data-testid="stSidebar"] {
  background: var(--bg-surface);
  border-right: 1px solid var(--border);
}

/* ── Sidebar branding ─────────────────────────────────────────────────── */
.sidebar-brand {
  padding: 1.5rem 1rem 1rem;
  border-bottom: 1px solid var(--border);
  margin-bottom: 1rem;
}
.sidebar-brand h1 {
  font-size: 1.5rem;
  font-weight: 800;
  background: linear-gradient(135deg, #6366F1, #8B5CF6);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  margin: 0;
  letter-spacing: -0.5px;
}
.sidebar-brand p {
  color: var(--text-3);
  font-size: 0.72rem;
  margin: 0.2rem 0 0;
  text-transform: uppercase;
  letter-spacing: 1px;
}

/* ── Navigation items ─────────────────────────────────────────────────── */
.nav-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.65rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.9rem;
  color: var(--text-2);
  transition: all 0.15s;
  margin-bottom: 2px;
}
.nav-item:hover, .nav-item.active {
  background: rgba(99,102,241,0.15);
  color: var(--text-1);
}
.nav-item.active { color: #818CF8; font-weight: 600; }

/* ── KPI cards ────────────────────────────────────────────────────────── */
.kpi-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 1rem;
  margin-bottom: 1.5rem;
}
.kpi-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.2rem 1.4rem;
  position: relative;
  overflow: hidden;
}
.kpi-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 3px;
  background: linear-gradient(90deg, var(--accent), var(--accent-2));
}
.kpi-icon { font-size: 1.4rem; margin-bottom: 0.5rem; }
.kpi-value {
  font-size: 1.7rem;
  font-weight: 800;
  color: var(--text-1);
  letter-spacing: -1px;
  line-height: 1;
}
.kpi-label {
  font-size: 0.75rem;
  color: var(--text-3);
  text-transform: uppercase;
  letter-spacing: 0.8px;
  margin-top: 0.35rem;
}

/* ── Section heading ──────────────────────────────────────────────────── */
.section-heading {
  font-size: 1rem;
  font-weight: 700;
  color: var(--text-2);
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 2rem 0 1rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}
.section-heading::after {
  content: '';
  flex: 1;
  height: 1px;
  background: var(--border);
}

/* ── Chart card ───────────────────────────────────────────────────────── */
.chart-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px;
  padding: 1.2rem;
  margin-bottom: 1rem;
}
.chart-title {
  font-size: 0.85rem;
  font-weight: 600;
  color: var(--text-2);
  text-transform: uppercase;
  letter-spacing: 0.8px;
  margin-bottom: 0.75rem;
}

/* ── Insight card ─────────────────────────────────────────────────────── */
.insight-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-left: 3px solid var(--accent);
  border-radius: 8px;
  padding: 1rem 1.2rem;
  margin-bottom: 0.75rem;
  display: flex;
  gap: 0.75rem;
  align-items: flex-start;
}
.insight-card.high  { border-left-color: var(--danger); }
.insight-card.medium { border-left-color: var(--warn); }
.insight-card.low   { border-left-color: var(--success); }
.insight-icon { font-size: 1.1rem; flex-shrink: 0; padding-top: 1px; }
.insight-text { font-size: 0.88rem; color: var(--text-2); line-height: 1.5; }

/* ── Upload zone ──────────────────────────────────────────────────────── */
.upload-zone {
  background: var(--bg-card);
  border: 2px dashed var(--border);
  border-radius: 16px;
  padding: 3rem 2rem;
  text-align: center;
  transition: border-color 0.2s;
}
.upload-zone:hover { border-color: var(--accent); }
.upload-title { font-size: 1.3rem; font-weight: 700; color: var(--text-1); }
.upload-sub   { color: var(--text-3); font-size: 0.85rem; margin-top: 0.4rem; }

/* ── Data quality badge ───────────────────────────────────────────────── */
.quality-badge {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.3rem 0.8rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
}
.quality-good   { background: rgba(16,185,129,0.15); color: #10B981; }
.quality-medium { background: rgba(245,158,11,0.15); color: #F59E0B; }
.quality-poor   { background: rgba(239,68,68,0.15);  color: #EF4444; }

/* ── Chat ─────────────────────────────────────────────────────────────── */
.chat-bubble-user {
  background: rgba(99,102,241,0.15);
  border: 1px solid rgba(99,102,241,0.3);
  border-radius: 12px 12px 4px 12px;
  padding: 0.75rem 1rem;
  margin: 0.5rem 0 0.5rem 15%;
  font-size: 0.88rem;
  color: var(--text-1);
}
.chat-bubble-assistant {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 12px 12px 12px 4px;
  padding: 0.75rem 1rem;
  margin: 0.5rem 15% 0.5rem 0;
  font-size: 0.88rem;
  color: var(--text-2);
}

/* ── Streamlit widget overrides ───────────────────────────────────────── */
.stButton > button {
  background: linear-gradient(135deg, #6366F1, #8B5CF6) !important;
  color: white !important;
  border: none !important;
  border-radius: 8px !important;
  font-weight: 600 !important;
  padding: 0.5rem 1.5rem !important;
}
.stButton > button:hover { opacity: 0.9 !important; }

div[data-testid="stFileUploader"] {
  background: var(--bg-card) !important;
  border: 2px dashed var(--border) !important;
  border-radius: 12px !important;
  padding: 1rem !important;
}

.stTabs [data-baseweb="tab-list"] {
  background: var(--bg-surface) !important;
  border-bottom: 1px solid var(--border) !important;
  gap: 0 !important;
}
.stTabs [data-baseweb="tab"] {
  color: var(--text-3) !important;
  font-weight: 500 !important;
  padding: 0.7rem 1.2rem !important;
}
.stTabs [aria-selected="true"] {
  color: var(--accent) !important;
  border-bottom: 2px solid var(--accent) !important;
  background: transparent !important;
}

.stDataFrame { border-radius: 8px; overflow: hidden; }
</style>
""", unsafe_allow_html=True)


# ── Session state ──────────────────────────────────────────────────────────────

def _init_state():
    defaults = {
        "page": "upload",
        "df": None,
        "detection": None,
        "kpis": None,
        "charts": None,
        "insights": None,
        "quality": None,
        "file_name": "",
        "chat_history": [],
        "processing": False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

_init_state()


# ── Sidebar ────────────────────────────────────────────────────────────────────

def _sidebar():
    with st.sidebar:
        st.markdown("""
        <div class="sidebar-brand">
          <h1>⚡ InsightFlow</h1>
          <p>AI Dashboard Generator</p>
        </div>
        """, unsafe_allow_html=True)

        nav_items = [
            ("upload",    "📤", "Upload"),
            ("dashboard", "📊", "Dashboard"),
            ("insights",  "💡", "Insights"),
            ("chat",      "💬", "Chat with Data"),
            ("quality",   "🔬", "Data Quality"),
        ]

        for page_id, icon, label in nav_items:
            active = "active" if st.session_state.page == page_id else ""
            disabled = page_id != "upload" and st.session_state.df is None
            if disabled:
                st.markdown(
                    f'<div class="nav-item" style="opacity:0.35">{icon} {label}</div>',
                    unsafe_allow_html=True,
                )
            else:
                if st.button(f"{icon}  {label}", key=f"nav_{page_id}",
                             use_container_width=True):
                    st.session_state.page = page_id
                    st.rerun()

        if st.session_state.df is not None:
            st.markdown("---")
            st.markdown(f"""
            <div style="padding:0 0.5rem;font-size:0.78rem;color:var(--text-3)">
                <div>📁 {st.session_state.file_name}</div>
                <div style="margin-top:4px">{len(st.session_state.df):,} rows</div>
            </div>
            """, unsafe_allow_html=True)


# ── Pages ──────────────────────────────────────────────────────────────────────

def _page_upload():
    st.markdown("## Upload your data")
    st.markdown(
        '<p style="color:var(--text-3);margin-top:-0.5rem">Excel or CSV · up to 50 MB</p>',
        unsafe_allow_html=True,
    )

    uploaded = st.file_uploader(
        "Drop your file here",
        type=["xlsx", "xls", "csv"],
        label_visibility="collapsed",
    )

    if uploaded and not st.session_state.processing:
        if st.button("⚡  Analyse Now", use_container_width=False):
            _run_pipeline(uploaded)


def _run_pipeline(uploaded):
    st.session_state.processing = True

    with st.spinner("Analysing your data…"):
        progress = st.progress(0, "Reading file…")
        time.sleep(0.2)

        try:
            # 1. Ingest
            ingestion = DataIngestionService()
            sheets = ingestion.read_file(
                io.BytesIO(uploaded.read()), uploaded.name
            )
            if not sheets:
                st.error("No usable data found in file.")
                return
            _, df_raw = next(iter(sheets.items()))
            progress.progress(20, "Cleaning data…")
            time.sleep(0.1)

            # 2. Clean
            cleaner = DataCleaningService()
            df, quality = cleaner.clean(df_raw)
            progress.progress(40, "Detecting column meanings…")
            time.sleep(0.1)

            # 3. Detect
            detection = detect_headers(df.columns.tolist())
            progress.progress(60, "Computing KPIs…")
            time.sleep(0.1)

            # 4. KPIs
            kpis = KPIEngine().compute(df, detection)
            progress.progress(75, "Building charts…")
            time.sleep(0.1)

            # 5. Charts
            charts = ChartEngine().generate(df, detection)
            progress.progress(88, "Generating insights…")
            time.sleep(0.1)

            # 6. Insights
            insights = InsightsEngine().generate(df, detection, kpis, quality)
            progress.progress(100, "Done ✓")

            # Persist in session
            st.session_state.df        = df
            st.session_state.detection = detection
            st.session_state.kpis      = kpis
            st.session_state.charts    = charts
            st.session_state.insights  = insights
            st.session_state.quality   = quality
            st.session_state.file_name = uploaded.name
            st.session_state.page      = "dashboard"

        except Exception as e:
            st.error(f"Failed to process file: {e}")
        finally:
            st.session_state.processing = False

    st.rerun()


def _kpi_html(kpis) -> str:
    cards = ""
    for k in kpis:
        cards += f"""
        <div class="kpi-card">
          <div class="kpi-icon">{k.icon}</div>
          <div class="kpi-value">{k.formatted}</div>
          <div class="kpi-label">{k.name}</div>
        </div>"""
    return f'<div class="kpi-grid">{cards}</div>'


def _page_dashboard():
    df = st.session_state.df
    detection = st.session_state.detection
    kpis = st.session_state.kpis
    charts = st.session_state.charts

    # Header
    col_h, col_badge = st.columns([4, 1])
    with col_h:
        st.markdown(f"## {st.session_state.file_name}")
        st.markdown(
            f'<p style="color:var(--text-3)">'
            f'{len(df):,} rows · {len(df.columns)} columns · '
            f'{len(detection.detected_domains)} business domains detected</p>',
            unsafe_allow_html=True,
        )
    with col_badge:
        qs = st.session_state.quality.quality_score
        cls = "quality-good" if qs >= 80 else "quality-medium" if qs >= 60 else "quality-poor"
        icon = "✅" if qs >= 80 else "⚠️" if qs >= 60 else "❌"
        st.markdown(
            f'<div style="text-align:right;padding-top:1.5rem">'
            f'<span class="quality-badge {cls}">{icon} {qs:.0f}/100 Quality</span>'
            f'</div>',
            unsafe_allow_html=True,
        )

    # KPI row
    st.markdown('<div class="section-heading">Key Metrics</div>', unsafe_allow_html=True)
    if kpis:
        st.markdown(_kpi_html(kpis), unsafe_allow_html=True)
    else:
        st.info("No KPIs could be computed from this dataset.")

    # Charts in 2-column grid
    if charts:
        st.markdown('<div class="section-heading">Charts</div>', unsafe_allow_html=True)
        col_a, col_b = st.columns(2, gap="medium")
        for i, chart in enumerate(charts):
            target = col_a if i % 2 == 0 else col_b
            with target:
                st.markdown(
                    f'<div class="chart-title">{chart.title}</div>',
                    unsafe_allow_html=True,
                )
                st.plotly_chart(
                    chart.figure,
                    use_container_width=True,
                    config={"displayModeBar": False},
                )
    else:
        st.info("Not enough data to generate charts automatically.")

    # Column mapping table
    with st.expander("🗂️  Column Detection Map", expanded=False):
        rows = [
            {
                "Original Column": c.raw_name,
                "Business Name": c.canonical_name or "—",
                "Category": c.category or "—",
                "Confidence": f"{c.confidence:.0%}" if c.confidence else "—",
                "Method": c.match_method,
            }
            for c in detection.columns
        ]
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)


def _page_insights():
    insights = st.session_state.insights
    if not insights:
        st.info("No insights available. Upload a dataset first.")
        return

    st.markdown("## AI Business Insights")
    st.markdown(
        '<p style="color:var(--text-3);margin-top:-0.5rem">'
        'Automatically generated from your data</p>',
        unsafe_allow_html=True,
    )

    # Group by importance
    for level, label, desc in [
        ("high",   "⚠️  Critical Findings", "Require immediate attention"),
        ("medium", "📊  Notable Patterns",  "Worth monitoring"),
        ("low",    "ℹ️  Additional Notes",  "Informational"),
    ]:
        level_insights = [i for i in insights if i.importance == level]
        if not level_insights:
            continue

        st.markdown(
            f'<div class="section-heading">{label}</div>',
            unsafe_allow_html=True,
        )
        for ins in level_insights:
            st.markdown(f"""
            <div class="insight-card {level}">
              <div class="insight-icon">{ins.icon}</div>
              <div class="insight-text">{ins.text}</div>
            </div>
            """, unsafe_allow_html=True)


def _page_chat():
    st.markdown("## Chat with Your Data")
    st.markdown(
        '<p style="color:var(--text-3);margin-top:-0.5rem">'
        'Ask questions about your dataset in plain English</p>',
        unsafe_allow_html=True,
    )

    # Suggested questions
    suggestions = [
        "What is the total revenue?",
        "How many unique customers are there?",
        "Show me a summary of insights",
        "What is the data quality score?",
        "Which columns were detected?",
    ]
    st.markdown("**Quick questions:**")
    cols = st.columns(len(suggestions))
    for i, sug in enumerate(suggestions):
        with cols[i]:
            if st.button(sug, key=f"sug_{i}", use_container_width=True):
                st.session_state.chat_history.append({"role": "user", "content": sug})
                _chat_answer(sug)

    st.markdown("---")

    # Chat history
    for msg in st.session_state.chat_history:
        css = "chat-bubble-user" if msg["role"] == "user" else "chat-bubble-assistant"
        st.markdown(
            f'<div class="{css}">{msg["content"]}</div>',
            unsafe_allow_html=True,
        )

    # Input
    user_input = st.chat_input("Ask anything about your data…")
    if user_input:
        st.session_state.chat_history.append({"role": "user", "content": user_input})
        _chat_answer(user_input)
        st.rerun()


def _chat_answer(question: str):
    """Generate answer from stored analysis (no server call needed)."""
    from backend.api.dashboard_router import _rule_based_answer

    kpis_raw = [
        {"name": k.name, "value": k.value, "formatted": k.formatted,
         "icon": k.icon, "description": k.description}
        for k in (st.session_state.kpis or [])
    ]
    insights_raw = [
        {"text": i.text, "category": i.category,
         "importance": i.importance, "icon": i.icon}
        for i in (st.session_state.insights or [])
    ]
    detection = st.session_state.detection
    ctx = {
        "file_name": st.session_state.file_name,
        "rows": len(st.session_state.df) if st.session_state.df is not None else 0,
        "columns": len(st.session_state.df.columns) if st.session_state.df is not None else 0,
        "kpis": kpis_raw,
        "insights": insights_raw,
        "quality_score": st.session_state.quality.quality_score if st.session_state.quality else None,
        "columns_detected": [
            f"{c.raw_name} → {c.canonical_name}"
            for c in detection.columns if c.canonical_name
        ] if detection else [],
    }
    answer = _rule_based_answer(question, ctx, kpis_raw, insights_raw)
    st.session_state.chat_history.append({"role": "assistant", "content": answer})


def _page_quality():
    quality = st.session_state.quality
    if quality is None:
        st.info("No data quality report available. Upload a dataset first.")
        return

    st.markdown("## Data Quality Report")

    qs = quality.quality_score
    cls = "quality-good" if qs >= 80 else "quality-medium" if qs >= 60 else "quality-poor"
    icon = "✅" if qs >= 80 else "⚠️" if qs >= 60 else "❌"

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Quality Score", f"{qs:.0f}/100")
    m2.metric("Total Rows", f"{quality.total_rows:,}")
    m3.metric("Duplicates Removed", quality.duplicate_rows)
    m4.metric("Blank Rows Removed", quality.blank_rows)

    if quality.global_issues:
        st.markdown('<div class="section-heading">Global Issues</div>', unsafe_allow_html=True)
        for issue in quality.global_issues:
            st.warning(issue)

    # Column quality table
    st.markdown('<div class="section-heading">Column Analysis</div>', unsafe_allow_html=True)
    rows = []
    for c in quality.columns:
        status = "✅ Good"
        if c.null_pct > 50:
            status = "❌ Critical"
        elif c.null_pct > 10 or c.issues:
            status = "⚠️ Issues"
        rows.append({
            "Column": c.column,
            "Type": c.dtype,
            "Missing": f"{c.null_pct:.1f}%",
            "Unique": c.unique_count,
            "Status": status,
            "Issues": "; ".join(c.issues) if c.issues else "—",
        })
    df_q = pd.DataFrame(rows)
    st.dataframe(df_q, use_container_width=True, hide_index=True)

    # Missing-value bar chart
    missing = [(c.column, c.null_pct) for c in quality.columns if c.null_pct > 0]
    if missing:
        missing_df = pd.DataFrame(missing, columns=["Column", "Missing %"])
        missing_df.sort_values("Missing %", ascending=False, inplace=True)
        fig = px.bar(
            missing_df, x="Column", y="Missing %",
            color="Missing %",
            color_continuous_scale=["#10B981", "#F59E0B", "#EF4444"],
        )
        fig.update_layout(
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            font=dict(color="#94A3B8"),
            margin=dict(l=20, r=20, t=30, b=20),
            showlegend=False,
        )
        st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


# ── Router ─────────────────────────────────────────────────────────────────────

def main():
    _sidebar()

    page = st.session_state.page

    if page == "upload":
        _page_upload()
    elif page == "dashboard":
        if st.session_state.df is None:
            st.session_state.page = "upload"
            st.rerun()
        _page_dashboard()
    elif page == "insights":
        _page_insights()
    elif page == "chat":
        _page_chat()
    elif page == "quality":
        _page_quality()


if __name__ == "__main__":
    main()
