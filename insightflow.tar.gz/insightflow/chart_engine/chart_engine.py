"""
InsightFlow - Chart Engine
Automatically selects and generates Plotly charts based on
detected column roles in the dataset.

Each chart function receives a cleaned DataFrame and returns
a plotly.graph_objects.Figure (or None if data is insufficient).
"""

import logging
from dataclasses import dataclass

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from header_detection.detector import DetectionReport, get_kpi_columns

logger = logging.getLogger(__name__)

# ── Design tokens (dark-friendly palette) ────────────────────────────────────
PALETTE = [
    "#6366F1",  # indigo
    "#8B5CF6",  # violet
    "#EC4899",  # pink
    "#14B8A6",  # teal
    "#F59E0B",  # amber
    "#10B981",  # emerald
    "#3B82F6",  # blue
    "#EF4444",  # red
]

CHART_THEME = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(family="Inter, system-ui, sans-serif", color="#E2E8F0", size=12),
    margin=dict(l=20, r=20, t=40, b=20),
)


def _apply_theme(fig: go.Figure) -> go.Figure:
    fig.update_layout(**CHART_THEME)
    fig.update_xaxes(gridcolor="#1E293B", linecolor="#334155", tickfont_color="#94A3B8")
    fig.update_yaxes(gridcolor="#1E293B", linecolor="#334155", tickfont_color="#94A3B8")
    return fig


@dataclass
class ChartSpec:
    title: str
    figure: go.Figure
    chart_type: str       # "line" | "bar" | "pie" | "scatter" | "map"
    domain: str           # "revenue" | "product" | "customer" | "geography" | "inventory"
    description: str = ""


class ChartEngine:
    """
    Generates all relevant charts for a dataset.
    Call .generate() and receive a list of ChartSpec objects.
    """

    def generate(
        self,
        df: pd.DataFrame,
        detection: DetectionReport,
    ) -> list[ChartSpec]:
        charts: list[ChartSpec] = []
        groups = get_kpi_columns(detection)

        revenue_cols = groups["revenue"]
        qty_cols = groups["quantity"]
        date_cols = groups["date"]

        # Find dimension column names by category
        def _dim(category: str) -> str | None:
            for c in detection.columns:
                if c.category == category and c.raw_name in df.columns:
                    return c.raw_name
            return None

        customer_col = _dim("customer")
        product_col  = _dim("product")
        region_col   = _dim("geography")
        country_col  = next(
            (c.raw_name for c in detection.columns
             if c.canonical_name == "Country" and c.raw_name in df.columns),
            None,
        )

        rev_col = revenue_cols[0] if revenue_cols else None
        qty_col = qty_cols[0] if qty_cols else None
        date_col = date_cols[0] if date_cols else None

        # ── Time-series charts ────────────────────────────────────────────────
        if date_col and rev_col:
            charts += self._revenue_over_time(df, date_col, rev_col)

        # ── Product charts ────────────────────────────────────────────────────
        if product_col and rev_col:
            charts.append(self._top_products(df, product_col, rev_col))
        if product_col and qty_col:
            charts.append(self._product_units(df, product_col, qty_col))

        # ── Customer charts ───────────────────────────────────────────────────
        if customer_col and rev_col:
            charts.append(self._top_customers(df, customer_col, rev_col))

        # ── Geography charts ──────────────────────────────────────────────────
        if region_col and rev_col:
            charts.append(self._revenue_by_region(df, region_col, rev_col))
        if country_col and rev_col:
            charts.append(self._world_map(df, country_col, rev_col))

        # ── Profit vs Revenue ─────────────────────────────────────────────────
        profit_col = next(
            (c.raw_name for c in detection.columns
             if c.canonical_name == "Profit" and c.raw_name in df.columns),
            None,
        )
        if profit_col and rev_col and date_col:
            charts.append(self._profit_vs_revenue(df, date_col, rev_col, profit_col))

        logger.info("Generated %d charts.", len(charts))
        return [c for c in charts if c is not None]

    # ── Revenue over time ──────────────────────────────────────────────────────

    def _revenue_over_time(
        self, df: pd.DataFrame, date_col: str, rev_col: str
    ) -> list[ChartSpec]:
        charts = []
        try:
            df_t = df[[date_col, rev_col]].copy()
            df_t[date_col] = pd.to_datetime(df_t[date_col], errors="coerce")
            df_t[rev_col] = pd.to_numeric(df_t[rev_col], errors="coerce")
            df_t.dropna(inplace=True)

            if len(df_t) < 2:
                return []

            # Monthly aggregation
            df_t["Month"] = df_t[date_col].dt.to_period("M").dt.to_timestamp()
            monthly = df_t.groupby("Month")[rev_col].sum().reset_index()

            fig = px.line(
                monthly,
                x="Month",
                y=rev_col,
                markers=True,
                color_discrete_sequence=[PALETTE[0]],
            )
            fig.update_traces(
                line=dict(width=2.5),
                marker=dict(size=6, color=PALETTE[0]),
                fill="tozeroy",
                fillcolor="rgba(99,102,241,0.12)",
            )
            _apply_theme(fig)
            charts.append(ChartSpec(
                title="Monthly Revenue Trend",
                figure=fig,
                chart_type="line",
                domain="revenue",
                description="Total revenue aggregated by month.",
            ))

            # MoM growth
            if len(monthly) >= 2:
                monthly["MoM_Growth"] = monthly[rev_col].pct_change() * 100
                fig2 = px.bar(
                    monthly.dropna(),
                    x="Month",
                    y="MoM_Growth",
                    color_discrete_sequence=[PALETTE[3]],
                )
                _apply_theme(fig2)
                charts.append(ChartSpec(
                    title="Month-over-Month Revenue Growth (%)",
                    figure=fig2,
                    chart_type="bar",
                    domain="revenue",
                ))

        except Exception as e:
            logger.warning("revenue_over_time error: %s", e)
        return charts

    # ── Top products ───────────────────────────────────────────────────────────

    def _top_products(
        self, df: pd.DataFrame, product_col: str, rev_col: str, top_n: int = 10
    ) -> ChartSpec | None:
        try:
            agg = (
                df.groupby(product_col)[rev_col]
                .sum()
                .sort_values(ascending=False)
                .head(top_n)
                .reset_index()
            )
            fig = px.bar(
                agg,
                x=rev_col,
                y=product_col,
                orientation="h",
                color_discrete_sequence=[PALETTE[1]],
            )
            fig.update_layout(yaxis=dict(autorange="reversed"))
            _apply_theme(fig)
            return ChartSpec(
                title=f"Top {top_n} Products by Revenue",
                figure=fig,
                chart_type="bar",
                domain="product",
            )
        except Exception as e:
            logger.warning("top_products error: %s", e)
            return None

    # ── Product units sold ─────────────────────────────────────────────────────

    def _product_units(
        self, df: pd.DataFrame, product_col: str, qty_col: str, top_n: int = 10
    ) -> ChartSpec | None:
        try:
            agg = (
                df.groupby(product_col)[qty_col]
                .sum()
                .sort_values(ascending=False)
                .head(top_n)
                .reset_index()
            )
            fig = px.bar(
                agg,
                x=product_col,
                y=qty_col,
                color_discrete_sequence=[PALETTE[4]],
            )
            _apply_theme(fig)
            return ChartSpec(
                title=f"Top {top_n} Products by Units Sold",
                figure=fig,
                chart_type="bar",
                domain="product",
            )
        except Exception as e:
            logger.warning("product_units error: %s", e)
            return None

    # ── Top customers ──────────────────────────────────────────────────────────

    def _top_customers(
        self, df: pd.DataFrame, customer_col: str, rev_col: str, top_n: int = 10
    ) -> ChartSpec | None:
        try:
            agg = (
                df.groupby(customer_col)[rev_col]
                .sum()
                .sort_values(ascending=False)
                .head(top_n)
                .reset_index()
            )
            fig = px.bar(
                agg,
                x=rev_col,
                y=customer_col,
                orientation="h",
                color_discrete_sequence=[PALETTE[2]],
            )
            fig.update_layout(yaxis=dict(autorange="reversed"))
            _apply_theme(fig)
            return ChartSpec(
                title=f"Top {top_n} Customers by Revenue",
                figure=fig,
                chart_type="bar",
                domain="customer",
            )
        except Exception as e:
            logger.warning("top_customers error: %s", e)
            return None

    # ── Revenue by region ──────────────────────────────────────────────────────

    def _revenue_by_region(
        self, df: pd.DataFrame, region_col: str, rev_col: str
    ) -> ChartSpec | None:
        try:
            agg = (
                df.groupby(region_col)[rev_col]
                .sum()
                .reset_index()
                .sort_values(rev_col, ascending=False)
            )
            fig = px.pie(
                agg,
                names=region_col,
                values=rev_col,
                color_discrete_sequence=PALETTE,
                hole=0.4,
            )
            fig.update_traces(textinfo="percent+label")
            _apply_theme(fig)
            return ChartSpec(
                title="Revenue by Region",
                figure=fig,
                chart_type="pie",
                domain="geography",
            )
        except Exception as e:
            logger.warning("revenue_by_region error: %s", e)
            return None

    # ── World map ──────────────────────────────────────────────────────────────

    def _world_map(
        self, df: pd.DataFrame, country_col: str, rev_col: str
    ) -> ChartSpec | None:
        try:
            agg = df.groupby(country_col)[rev_col].sum().reset_index()
            fig = px.choropleth(
                agg,
                locations=country_col,
                locationmode="country names",
                color=rev_col,
                color_continuous_scale="Viridis",
            )
            fig.update_geos(showframe=False, showcoastlines=True, bgcolor="rgba(0,0,0,0)")
            _apply_theme(fig)
            return ChartSpec(
                title="Revenue by Country",
                figure=fig,
                chart_type="map",
                domain="geography",
            )
        except Exception as e:
            logger.warning("world_map error: %s", e)
            return None

    # ── Profit vs Revenue ──────────────────────────────────────────────────────

    def _profit_vs_revenue(
        self, df: pd.DataFrame, date_col: str, rev_col: str, profit_col: str
    ) -> ChartSpec | None:
        try:
            df_t = df[[date_col, rev_col, profit_col]].copy()
            df_t[date_col] = pd.to_datetime(df_t[date_col], errors="coerce")
            df_t[rev_col] = pd.to_numeric(df_t[rev_col], errors="coerce")
            df_t[profit_col] = pd.to_numeric(df_t[profit_col], errors="coerce")
            df_t.dropna(inplace=True)
            df_t["Month"] = df_t[date_col].dt.to_period("M").dt.to_timestamp()
            agg = df_t.groupby("Month")[[rev_col, profit_col]].sum().reset_index()

            fig = make_subplots(specs=[[{"secondary_y": True}]])
            fig.add_trace(
                go.Bar(x=agg["Month"], y=agg[rev_col], name="Revenue",
                       marker_color=PALETTE[0], opacity=0.8),
                secondary_y=False,
            )
            fig.add_trace(
                go.Scatter(x=agg["Month"], y=agg[profit_col], name="Profit",
                           line=dict(color=PALETTE[2], width=2.5), mode="lines+markers"),
                secondary_y=True,
            )
            _apply_theme(fig)
            return ChartSpec(
                title="Revenue vs Profit Over Time",
                figure=fig,
                chart_type="combo",
                domain="revenue",
            )
        except Exception as e:
            logger.warning("profit_vs_revenue error: %s", e)
            return None
